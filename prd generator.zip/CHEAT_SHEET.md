# Quick Reference Cheat Sheet

Print this out while you're learning!

---

## Python Basics

```python
# Variables
name = "John"           # String
age = 25                # Integer
items = ["a", "b"]      # List
user = {"name": "Jo"}   # Dictionary

# Dictionary access
user["name"]            # "Jo" (crashes if missing)
user.get("name")        # "Jo" (returns None if missing)
user.get("x", "default")# "default" (custom default)

# List operations
items.append("c")       # Add item
items[0]                # First item
items[-1]               # Last item
len(items)              # Count

# List comprehension
[x*2 for x in [1,2,3]]  # [2, 4, 6]

# Function
def greet(name):
    return f"Hello, {name}"

# File operations
with open("f.txt", "w") as f:
    f.write("content")

with open("f.txt", "r") as f:
    content = f.read()

# JSON
import json
json.dumps(data)        # Dict → String
json.loads(string)      # String → Dict
```

---

## Streamlit Components

```python
import streamlit as st

# Text
st.title("Title")
st.header("Header")
st.subheader("Subheader")
st.write("Text")
st.markdown("**Bold**")
st.caption("Small text")

# Input
name = st.text_input("Name")
text = st.text_area("Text", height=200)
option = st.selectbox("Pick", ["A", "B"])
checked = st.checkbox("Check me")

# Buttons
if st.button("Click"):
    st.write("Clicked!")

# Layout
col1, col2 = st.columns(2)
with col1:
    st.write("Left")
with col2:
    st.write("Right")

with st.sidebar:
    st.write("Sidebar")

with st.expander("Click to expand"):
    st.write("Hidden")

# Feedback
st.success("Success!")
st.error("Error!")
st.warning("Warning!")
st.info("Info")

# Progress
with st.spinner("Loading..."):
    time.sleep(2)

progress = st.progress(0)
progress.progress(50)

# Download
st.download_button("Download", content, "file.txt")

# Divider
st.divider()

# Rerun
st.rerun()
```

---

## Session State Pattern

```python
# Initialize (only runs once)
if "count" not in st.session_state:
    st.session_state.count = 0

# Use it
st.session_state.count += 1

# Page navigation pattern
if "page" not in st.session_state:
    st.session_state.page = "home"

if st.button("Go to About"):
    st.session_state.page = "about"
    st.rerun()

if st.session_state.page == "home":
    st.write("Home page")
elif st.session_state.page == "about":
    st.write("About page")
```

---

## Groq API

```python
from groq import Groq

client = Groq(api_key="gsk_...")

response = client.chat.completions.create(
    model="llama-3.3-70b-versatile",
    messages=[
        {"role": "user", "content": "Your prompt"}
    ],
    max_tokens=4096,
    temperature=0.3
)

answer = response.choices[0].message.content
```

---

## Storage Pattern

```python
from pathlib import Path
import json

FILE = Path.home() / ".myapp" / "data.json"

def init():
    FILE.parent.mkdir(exist_ok=True)
    if not FILE.exists():
        FILE.write_text("[]")

def load():
    init()
    return json.loads(FILE.read_text())

def save(items):
    init()
    FILE.write_text(json.dumps(items, indent=2))
```

---

## Error Handling

```python
# Basic try/except
try:
    result = risky_operation()
except Exception as e:
    st.error(f"Error: {e}")

# Retry with exponential backoff
for attempt in range(3):
    try:
        result = api_call()
        break
    except Exception:
        time.sleep(2 ** attempt)  # 1s, 2s, 4s
```

---

## Optional Imports

```python
try:
    from docx import Document
    DOCX_OK = True
except ImportError:
    DOCX_OK = False

# Later
if DOCX_OK:
    st.button("Word Export")
else:
    st.button("Word (not installed)", disabled=True)
```

---

## Export Functions

```python
# Markdown
def export_md(prd):
    return f"# {prd['name']}\n\n{prd['content']}"

# Download
st.download_button(
    "Download",
    export_md(prd),
    "file.md",
    "text/markdown"
)
```

---

## Sharing (Base64)

```python
import base64

def encode(data):
    json_str = json.dumps(data)
    return base64.urlsafe_b64encode(json_str.encode()).decode()

def decode(encoded):
    json_str = base64.urlsafe_b64decode(encoded).decode()
    return json.loads(json_str)

# URL: http://localhost:8501/?shared=ENCODED_STRING
params = st.query_params
if "shared" in params:
    data = decode(params["shared"])
```

---

## Key Concepts to Remember

1. **Streamlit reruns entire script on every interaction**
2. **Use session_state for data that must persist**
3. **st.rerun() refreshes the page**
4. **Dictionaries: use .get() to avoid crashes**
5. **Always handle errors with try/except**
6. **API calls need retry logic**
7. **JSON files: good for simple storage**

---

## Learning Order

1. ✅ Python basics (variables, functions, loops)
2. ✅ Dictionaries and lists
3. ✅ File operations and JSON
4. ✅ Streamlit basics (widgets, layout)
5. ✅ Session state
6. ✅ API calls with Groq
7. ✅ Combine into full app

---

## Exercise Progression

```
Todo App (simple)
    ↓
Minimal PRD Generator (1 section)
    ↓
Full PRD Generator (8 sections)
    ↓
Add your own features!
```
