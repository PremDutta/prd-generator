# Learn to Build PRD Generator From Scratch

## The Truth

You can't explain what you don't understand. This guide teaches you to build everything yourself.

**Time required:** 1-2 weeks if you're new, 3-5 days if you know Python basics.

---

# PHASE 1: PREREQUISITES (Days 1-2)

## What You Need to Know First

### 1. Python Basics

If you don't know Python, spend 2 days on these:

**Variables and Data Types:**
```python
# Run these in Python terminal (type 'python' in command line)

name = "PRD Generator"        # String
count = 42                    # Integer
price = 19.99                 # Float
is_active = True              # Boolean
items = ["a", "b", "c"]       # List
user = {"name": "John", "age": 30}  # Dictionary
```

**Functions:**
```python
def greet(name):
    return f"Hello, {name}!"

result = greet("Sarah")
print(result)  # Hello, Sarah!
```

**Loops:**
```python
# For loop
for item in ["apple", "banana", "cherry"]:
    print(item)

# While loop
count = 0
while count < 3:
    print(count)
    count += 1
```

**Conditionals:**
```python
age = 25

if age < 18:
    print("Minor")
elif age < 65:
    print("Adult")
else:
    print("Senior")
```

**Dictionaries (VERY IMPORTANT - we use these everywhere):**
```python
# Create
user = {"name": "John", "age": 30}

# Access
print(user["name"])  # John
print(user.get("name"))  # John (safer, returns None if key missing)
print(user.get("email", "not found"))  # "not found"

# Update
user["age"] = 31
user["email"] = "john@example.com"

# Loop through
for key, value in user.items():
    print(f"{key}: {value}")
```

**Lists:**
```python
# Create
fruits = ["apple", "banana"]

# Add
fruits.append("cherry")

# Access
print(fruits[0])  # apple
print(fruits[-1])  # cherry (last item)

# Loop
for fruit in fruits:
    print(fruit)

# List comprehension (fancy way to create lists)
numbers = [1, 2, 3, 4, 5]
squares = [n * n for n in numbers]  # [1, 4, 9, 16, 25]

# Filter with list comprehension
evens = [n for n in numbers if n % 2 == 0]  # [2, 4]
```

**Exercise 1:** Create a dictionary representing a PRD with keys: name, problem, solution. Print each key-value pair.

---

### 2. File Operations

**Reading files:**
```python
# Method 1: Basic
file = open("myfile.txt", "r")
content = file.read()
file.close()

# Method 2: Better (auto-closes)
with open("myfile.txt", "r") as file:
    content = file.read()
```

**Writing files:**
```python
with open("myfile.txt", "w") as file:
    file.write("Hello, World!")
```

**JSON files (we use this for storage):**
```python
import json

# Write JSON
data = {"name": "John", "age": 30}
with open("data.json", "w") as file:
    json.dump(data, file)

# Read JSON
with open("data.json", "r") as file:
    data = json.load(file)
    print(data["name"])  # John
```

**Exercise 2:** 
1. Create a list of 3 PRD dictionaries
2. Save them to a JSON file
3. Read them back and print the first PRD's name

---

### 3. Installing Packages

**pip** is Python's package manager.

```bash
# Install a package
pip install streamlit

# Install multiple
pip install streamlit groq python-docx

# Install from requirements file
pip install -r requirements.txt

# See what's installed
pip list
```

**Exercise 3:** Install streamlit and verify with `pip list`

---

# PHASE 2: LEARN STREAMLIT (Days 3-4)

## What is Streamlit?

Streamlit turns Python scripts into web apps. Every time you interact with the app (click button, type text), the entire script runs again from top to bottom.

## Step-by-Step Streamlit Learning

### Lesson 1: Hello World

Create file `app.py`:
```python
import streamlit as st

st.title("Hello World")
st.write("This is my first Streamlit app")
```

Run it:
```bash
streamlit run app.py
```

Open browser to http://localhost:8501

**What happened?**
- `import streamlit as st` - Load Streamlit, call it "st" for short
- `st.title()` - Display a title
- `st.write()` - Display text

---

### Lesson 2: Input Widgets

```python
import streamlit as st

st.title("Input Examples")

# Text input
name = st.text_input("What's your name?")
st.write(f"Hello, {name}!")

# Text area (multi-line)
bio = st.text_area("Tell me about yourself", height=150)

# Button
if st.button("Click me"):
    st.write("Button was clicked!")

# Selectbox (dropdown)
color = st.selectbox("Pick a color", ["Red", "Green", "Blue"])
st.write(f"You picked: {color}")
```

**Key insight:** When you type in text_input, the script reruns. The variable `name` gets the new value.

---

### Lesson 3: Layout

```python
import streamlit as st

st.title("Layout Examples")

# Sidebar
with st.sidebar:
    st.header("Sidebar")
    option = st.selectbox("Choose", ["A", "B", "C"])

# Columns
col1, col2 = st.columns(2)

with col1:
    st.header("Left Column")
    st.write("Content here")

with col2:
    st.header("Right Column")
    st.write("More content")

# Expander (collapsible)
with st.expander("Click to expand"):
    st.write("Hidden content!")

# Divider
st.divider()
st.write("After divider")
```

---

### Lesson 4: Session State (CRITICAL!)

**Problem:** Every interaction reruns the script. Variables reset!

```python
import streamlit as st

# This WON'T work - count resets to 0 every time
count = 0
if st.button("Add 1"):
    count += 1
st.write(f"Count: {count}")  # Always shows 0 or 1
```

**Solution:** Session state persists across reruns.

```python
import streamlit as st

# Initialize session state (only runs once)
if "count" not in st.session_state:
    st.session_state.count = 0

# Now it works!
if st.button("Add 1"):
    st.session_state.count += 1

st.write(f"Count: {st.session_state.count}")
```

**Exercise 4:** Build a simple counter app with +1 and -1 buttons using session state.

---

### Lesson 5: Page Navigation Pattern

```python
import streamlit as st

# Initialize page state
if "page" not in st.session_state:
    st.session_state.page = "home"

# Sidebar navigation
with st.sidebar:
    if st.button("Home"):
        st.session_state.page = "home"
    if st.button("About"):
        st.session_state.page = "about"
    if st.button("Contact"):
        st.session_state.page = "contact"

# Page routing
if st.session_state.page == "home":
    st.title("Home Page")
    st.write("Welcome!")

elif st.session_state.page == "about":
    st.title("About Page")
    st.write("This is about us.")

elif st.session_state.page == "contact":
    st.title("Contact Page")
    st.write("Email: test@test.com")
```

**What's happening:**
1. We store current page in session state
2. Buttons change the page value
3. if/elif shows different content based on page

---

### Lesson 6: Forms and Rerun

```python
import streamlit as st

st.title("Form Example")

# Get input
name = st.text_input("Name")
email = st.text_input("Email")

if st.button("Submit"):
    if name and email:
        st.success(f"Saved: {name}, {email}")
    else:
        st.error("Please fill all fields")

# st.rerun() - forces page to refresh
# Useful after changing session state
```

---

### Lesson 7: Download Button

```python
import streamlit as st

content = """# My Document

This is the content of my document.

## Section 1
Some text here.
"""

st.download_button(
    label="Download as Markdown",
    data=content,
    file_name="document.md",
    mime="text/markdown"
)
```

---

### Exercise 5: Build a Mini Note App

Build an app that:
1. Has a text input for note title
2. Has a text area for note content
3. Has a "Save" button that stores the note in session state
4. Shows a list of saved notes below
5. Has a download button for each note

This is 80% of what our PRD generator does!

---

# PHASE 3: LEARN API CALLS (Day 5)

## What is an API?

API = Application Programming Interface

It's how programs talk to each other. You send a request, you get a response.

**Analogy:** Restaurant
- You (client) → Waiter (API) → Kitchen (server)
- You don't go to kitchen directly, you talk to waiter

## HTTP Basics

```
GET    - Retrieve data (read)
POST   - Send data (create)
PUT    - Update data
DELETE - Remove data
```

For AI APIs, we use POST to send our prompt and get a response.

## Using the requests library

```python
import requests

# GET request
response = requests.get("https://api.example.com/data")
print(response.status_code)  # 200 = success
print(response.json())  # Parse JSON response

# POST request
response = requests.post(
    "https://api.example.com/data",
    headers={"Authorization": "Bearer YOUR_API_KEY"},
    json={"prompt": "Hello, world!"}
)
data = response.json()
```

## Groq API Specifically

```python
from groq import Groq

# Initialize client with API key
client = Groq(api_key="gsk_your_key_here")

# Make a request
response = client.chat.completions.create(
    model="llama-3.3-70b-versatile",
    messages=[
        {"role": "user", "content": "What is 2+2?"}
    ],
    max_tokens=100,
    temperature=0.3
)

# Extract the response text
answer = response.choices[0].message.content
print(answer)
```

**Breaking it down:**

1. `Groq(api_key=...)` - Creates client with your credentials
2. `client.chat.completions.create()` - Sends request to API
3. `model` - Which AI model to use
4. `messages` - The conversation (just one message for us)
5. `max_tokens` - Maximum response length
6. `temperature` - 0=consistent, 1=creative
7. `response.choices[0].message.content` - The actual text response

**Exercise 6:**
1. Get free API key from console.groq.com/keys
2. Install groq: `pip install groq`
3. Write a script that asks the AI "What is Python?"
4. Print the response

---

# PHASE 4: BUILD THE PRD GENERATOR (Days 6-8)

Now we combine everything. Build it piece by piece.

## Step 1: Basic Structure

Create `prd_generator.py`:

```python
import streamlit as st

st.set_page_config(page_title="PRD Generator", layout="wide")

# Session state
if "page" not in st.session_state:
    st.session_state.page = "home"

# Sidebar
with st.sidebar:
    st.title("PRD Generator")
    
    if st.button("Home"):
        st.session_state.page = "home"
    if st.button("New PRD"):
        st.session_state.page = "new"
    if st.button("My PRDs"):
        st.session_state.page = "history"

# Pages
if st.session_state.page == "home":
    st.title("Welcome to PRD Generator")
    st.write("Click 'New PRD' to get started")

elif st.session_state.page == "new":
    st.title("Create New PRD")
    st.write("Form will go here")

elif st.session_state.page == "history":
    st.title("My PRDs")
    st.write("List will go here")
```

Run it: `streamlit run prd_generator.py`

You now have a working multi-page app!

---

## Step 2: Add Input Form

Update the "new" page:

```python
elif st.session_state.page == "new":
    st.title("Create New PRD")
    
    # Form inputs
    prd_name = st.text_input("PRD Name", placeholder="e.g., Data Export Feature")
    
    raw_input = st.text_area(
        "Your Notes",
        height=300,
        placeholder="Describe your feature..."
    )
    
    if st.button("Generate PRD"):
        if not prd_name:
            st.error("Please enter a name")
        elif not raw_input:
            st.error("Please enter your notes")
        else:
            st.success(f"Generating PRD for: {prd_name}")
            # Generation will go here
```

---

## Step 3: Add AI Generation

First, add the API client:

```python
import streamlit as st
from groq import Groq

# At the top, after imports
def get_ai_response(prompt, api_key):
    """Send prompt to AI and get response"""
    client = Groq(api_key=api_key)
    
    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=4096,
        temperature=0.3
    )
    
    return response.choices[0].message.content
```

Add API key input to sidebar:

```python
with st.sidebar:
    st.title("PRD Generator")
    
    # Navigation buttons...
    
    st.divider()
    
    api_key = st.text_input("Groq API Key", type="password")
    if api_key:
        st.success("API Key set")
    else:
        st.warning("Enter API Key")
```

Update generation button:

```python
if st.button("Generate PRD"):
    if not prd_name:
        st.error("Please enter a name")
    elif not raw_input:
        st.error("Please enter your notes")
    elif not api_key:
        st.error("Please enter API key in sidebar")
    else:
        with st.spinner("Generating..."):
            prompt = f"""Write a PRD overview for this feature:
            
Feature: {prd_name}

Notes: {raw_input}

Write a professional 3-4 sentence overview."""
            
            result = get_ai_response(prompt, api_key)
            st.subheader("Generated Overview")
            st.write(result)
```

---

## Step 4: Add Multiple Sections

Define sections:

```python
SECTIONS = [
    {"id": "overview", "name": "Overview", "prompt": "Write a 3-4 sentence overview."},
    {"id": "problem", "name": "Problem Statement", "prompt": "Describe the problem being solved."},
    {"id": "goals", "name": "Goals", "prompt": "List 3-5 measurable goals."},
    {"id": "solution", "name": "Solution", "prompt": "Describe the proposed solution."},
]
```

Generate all sections:

```python
if st.button("Generate PRD"):
    if not prd_name or not raw_input or not api_key:
        st.error("Please fill all fields")
    else:
        progress = st.progress(0)
        
        generated_sections = {}
        
        for i, section in enumerate(SECTIONS):
            st.text(f"Generating: {section['name']}...")
            progress.progress((i + 1) / len(SECTIONS))
            
            prompt = f"""You are a senior PM. Write the {section['name']} section.

Feature: {prd_name}
Notes: {raw_input}

{section['prompt']}

Write only the content, no header."""
            
            content = get_ai_response(prompt, api_key)
            generated_sections[section['id']] = content
        
        # Store in session state
        st.session_state.generated_sections = generated_sections
        st.session_state.prd_name = prd_name
        st.success("PRD Generated!")
        
        # Display sections
        for section in SECTIONS:
            st.subheader(section['name'])
            st.write(generated_sections[section['id']])
```

---

## Step 5: Add Storage

Add storage functions:

```python
import json
from pathlib import Path

STORAGE_FILE = Path.home() / ".prd_generator" / "prds.json"

def init_storage():
    """Create storage directory and file"""
    STORAGE_FILE.parent.mkdir(exist_ok=True)
    if not STORAGE_FILE.exists():
        STORAGE_FILE.write_text("[]")

def load_prds():
    """Load all PRDs from file"""
    init_storage()
    return json.loads(STORAGE_FILE.read_text())

def save_prd(prd):
    """Save a PRD to file"""
    prds = load_prds()
    prds.insert(0, prd)  # Add to front
    STORAGE_FILE.write_text(json.dumps(prds, indent=2))
```

Save after generation:

```python
# After generating all sections...
prd = {
    "id": str(int(time.time())),  # Simple unique ID
    "name": prd_name,
    "content": generated_sections,
    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
}
save_prd(prd)
st.success("PRD saved!")
```

Show in history:

```python
elif st.session_state.page == "history":
    st.title("My PRDs")
    
    prds = load_prds()
    
    if not prds:
        st.info("No PRDs yet")
    else:
        for prd in prds:
            st.subheader(prd["name"])
            st.caption(f"Created: {prd['created_at']}")
            
            with st.expander("View content"):
                for section_id, content in prd["content"].items():
                    st.markdown(f"**{section_id}**")
                    st.write(content)
            
            st.divider()
```

---

## Step 6: Add Export

```python
def export_markdown(prd):
    """Convert PRD to markdown string"""
    lines = [f"# PRD: {prd['name']}", ""]
    
    for section_id, content in prd["content"].items():
        lines.append(f"## {section_id.title()}")
        lines.append(content)
        lines.append("")
    
    return "\n".join(lines)
```

Add download button:

```python
# In history page, for each PRD
md_content = export_markdown(prd)
st.download_button(
    "Download",
    md_content,
    f"{prd['name']}.md",
    "text/markdown"
)
```

---

## Step 7: Add Section Editing

```python
# When displaying generated PRD
for section in SECTIONS:
    section_id = section['id']
    content = st.session_state.generated_sections[section_id]
    
    col1, col2 = st.columns([6, 1])
    with col1:
        st.subheader(section['name'])
    with col2:
        if st.button("Edit", key=f"edit_{section_id}"):
            st.session_state.editing = section_id
    
    # Show editor or content
    if st.session_state.get("editing") == section_id:
        new_content = st.text_area(
            "Edit",
            value=content,
            key=f"textarea_{section_id}"
        )
        if st.button("Save", key=f"save_{section_id}"):
            st.session_state.generated_sections[section_id] = new_content
            st.session_state.editing = None
            st.rerun()
    else:
        st.write(content)
```

---

# PHASE 5: POLISH (Days 9-10)

## Error Handling

```python
def get_ai_response(prompt, api_key, max_retries=3):
    """Send prompt with retry logic"""
    import time
    
    for attempt in range(max_retries):
        try:
            client = Groq(api_key=api_key)
            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=4096,
                temperature=0.3
            )
            return response.choices[0].message.content
        
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # Wait 1s, 2s, 4s
                continue
            else:
                raise e
```

**Why exponential backoff?**
- First failure: wait 1 second (2^0)
- Second failure: wait 2 seconds (2^1)
- Third failure: wait 4 seconds (2^2)
- Gives server time to recover

## Optional Imports

```python
# At top of file
try:
    from docx import Document
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

# When using
if DOCX_AVAILABLE:
    st.download_button("Word", docx_content)
else:
    st.button("Word (not installed)", disabled=True)
```

## Better Prompts

The secret sauce! Each section needs specific instructions:

```python
SECTIONS = [
    {
        "id": "problem",
        "name": "Problem Statement",
        "prompt": """Write a compelling Problem Statement.

Structure:
1. **The Problem** (2-3 sentences): What's broken? Be specific.
2. **Who's Affected**: Which users experience this?
3. **Cost of Inaction**: What happens if we don't solve this?

Use specific numbers. Example:
Bad: "Users find it hard to export"
Good: "Enterprise users (45% of revenue) cannot export to Excel, causing 10+ support tickets/week"

Write only the content, no header."""
    },
    # ... more sections
]
```

---

# PHASE 6: UNDERSTANDING THE COMPLETE CODE

Now let's trace through the final code section by section.

## Imports Section

```python
import json          # For saving/loading PRDs
import os            # For environment variables
import time          # For delays and timestamps
import base64        # For shareable links
import hashlib       # For generating IDs
from datetime import datetime  # For dates
from pathlib import Path      # For file paths
from typing import Optional, Dict, List  # Type hints
from io import BytesIO  # For Word export
import streamlit as st  # The web framework
```

Each import has a purpose. Don't import what you don't use.

## Configuration Section

```python
STORAGE_DIR = Path.home() / ".prd_generator"
PRDS_FILE = STORAGE_DIR / "prds.json"
```

`Path.home()` = Your home directory (/Users/you on Mac, C:\Users\you on Windows)

`/` with Path objects joins paths (like os.path.join but cleaner)

## Session State Initialization

```python
if "page" not in st.session_state:
    st.session_state.page = "home"
```

This pattern:
1. Check if variable exists in session state
2. If not, create it with default value
3. On subsequent runs, it already exists, so we skip

## The Main Loop

Streamlit runs your entire script on every interaction. So:

```python
# This runs EVERY TIME
st.title("My App")

# This only shows if condition is true
if st.session_state.page == "home":
    show_home_page()
```

Understanding this is key to Streamlit!

---

# EXERCISES TO CEMENT LEARNING

## Exercise A: Build a Todo App

Before building PRD generator, build a simpler app:

1. Add todos (text input + button)
2. Show todo list
3. Mark todos complete (checkbox)
4. Delete todos (button)
5. Save to JSON file
6. Download as text file

## Exercise B: Build a Quote Generator

1. Button to generate quote (use Groq API)
2. Save favorite quotes
3. Show history of quotes
4. Export quotes

## Exercise C: Modify PRD Generator

Once you understand the code:

1. Add a new section (e.g., "Technical Requirements")
2. Change the prompt for an existing section
3. Add a "duplicate PRD" feature
4. Add search to history page
5. Add sorting (by date, by name)

---

# COMMON MISTAKES & FIXES

## Mistake 1: Forgetting Session State

```python
# WRONG - count resets every time
count = 0
if st.button("Add"):
    count += 1

# RIGHT - count persists
if "count" not in st.session_state:
    st.session_state.count = 0
if st.button("Add"):
    st.session_state.count += 1
```

## Mistake 2: Not Handling Missing Keys

```python
# WRONG - crashes if key doesn't exist
value = my_dict["key"]

# RIGHT - returns None or default
value = my_dict.get("key")
value = my_dict.get("key", "default")
```

## Mistake 3: Not Handling API Errors

```python
# WRONG - crashes on error
response = client.generate(prompt)

# RIGHT - handle errors
try:
    response = client.generate(prompt)
except Exception as e:
    st.error(f"API Error: {e}")
```

## Mistake 4: Blocking UI During Generation

```python
# WRONG - user sees nothing
result = slow_function()

# RIGHT - show progress
with st.spinner("Loading..."):
    result = slow_function()
```

---

# INTERVIEW PREPARATION

After building this yourself, you can honestly say:

## Technical Questions

**Q: How does session state work?**
> "Streamlit reruns the entire script on every interaction. Session state is a dictionary that persists across reruns. I use it to store the current page, generated content, and user inputs that need to survive reruns."

**Q: How do you handle API failures?**
> "I implement retry logic with exponential backoff. If a request fails, I wait 1 second and retry, then 2 seconds, then 4 seconds. This handles temporary failures without overwhelming the server."

**Q: Why JSON file instead of database?**
> "For this scale, JSON is simpler - no setup required. The file lives in the user's home directory and persists across sessions. For production with multiple users, I'd use PostgreSQL."

## You Can Now Say Honestly

- "I built this from scratch"
- "I understand every line of code"
- "I can modify it to add features"
- "I learned Streamlit, API integration, and file storage"

---

# NEXT STEPS

1. **Build the todo app** (Exercise A) - 2-3 hours
2. **Build quote generator** (Exercise B) - 2-3 hours
3. **Build PRD generator from scratch** following this guide - 1 day
4. **Compare your code to mine** - understand differences
5. **Add your own features** - make it yours

The goal is not to memorize code, but to understand patterns:
- Session state for persistence
- API calls with error handling
- File storage with JSON
- Component-based UI

Once you understand the patterns, you can build anything.

---

**Good luck! Build it yourself, and you'll truly own it. 🚀**
