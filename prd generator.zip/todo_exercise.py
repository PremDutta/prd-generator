"""
EXERCISE: Build a Todo App
==========================
This is a simpler version of the PRD Generator.
Build this first to understand the patterns.

Run: streamlit run todo_exercise.py
"""

import streamlit as st
import json
from pathlib import Path
from datetime import datetime

# =============================================================================
# STEP 1: STORAGE
# =============================================================================

# Where to save todos
STORAGE_FILE = Path.home() / ".todo_app" / "todos.json"

def init_storage():
    """Create storage directory and file if they don't exist"""
    STORAGE_FILE.parent.mkdir(exist_ok=True)
    if not STORAGE_FILE.exists():
        STORAGE_FILE.write_text("[]")

def load_todos():
    """Load all todos from file"""
    init_storage()
    content = STORAGE_FILE.read_text()
    return json.loads(content) if content else []

def save_todos(todos):
    """Save all todos to file"""
    init_storage()
    STORAGE_FILE.write_text(json.dumps(todos, indent=2))

def add_todo(text):
    """Add a new todo"""
    todos = load_todos()
    todo = {
        "id": str(int(datetime.now().timestamp())),
        "text": text,
        "done": False,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
    }
    todos.insert(0, todo)
    save_todos(todos)

def toggle_todo(todo_id):
    """Mark todo as done/undone"""
    todos = load_todos()
    for todo in todos:
        if todo["id"] == todo_id:
            todo["done"] = not todo["done"]
            break
    save_todos(todos)

def delete_todo(todo_id):
    """Delete a todo"""
    todos = load_todos()
    todos = [t for t in todos if t["id"] != todo_id]
    save_todos(todos)

# =============================================================================
# STEP 2: STREAMLIT APP
# =============================================================================

st.set_page_config(page_title="Todo App", page_icon="✅")

st.title("✅ Todo App")
st.caption("A simple todo app to practice Streamlit")

# =============================================================================
# STEP 3: ADD TODO FORM
# =============================================================================

st.subheader("Add New Todo")

# Text input for new todo
new_todo = st.text_input("What do you need to do?", placeholder="Enter a task...")

# Add button
if st.button("Add Todo", type="primary"):
    if new_todo.strip():
        add_todo(new_todo.strip())
        st.success("Todo added!")
        st.rerun()  # Refresh to show new todo
    else:
        st.error("Please enter a task")

st.divider()

# =============================================================================
# STEP 4: SHOW TODOS
# =============================================================================

st.subheader("My Todos")

todos = load_todos()

if not todos:
    st.info("No todos yet. Add one above!")
else:
    # Count stats
    total = len(todos)
    done = len([t for t in todos if t["done"]])
    st.caption(f"Completed: {done}/{total}")
    
    # Show each todo
    for todo in todos:
        col1, col2, col3 = st.columns([1, 4, 1])
        
        with col1:
            # Checkbox to mark done
            is_done = st.checkbox(
                "Done",
                value=todo["done"],
                key=f"check_{todo['id']}",
                label_visibility="collapsed"
            )
            if is_done != todo["done"]:
                toggle_todo(todo["id"])
                st.rerun()
        
        with col2:
            # Show todo text (strikethrough if done)
            if todo["done"]:
                st.markdown(f"~~{todo['text']}~~")
            else:
                st.write(todo["text"])
            st.caption(todo["created_at"])
        
        with col3:
            # Delete button
            if st.button("🗑️", key=f"del_{todo['id']}"):
                delete_todo(todo["id"])
                st.rerun()

st.divider()

# =============================================================================
# STEP 5: EXPORT
# =============================================================================

st.subheader("Export")

if todos:
    # Create text content
    lines = ["# My Todos", ""]
    for todo in todos:
        status = "✅" if todo["done"] else "⬜"
        lines.append(f"{status} {todo['text']}")
    export_content = "\n".join(lines)
    
    st.download_button(
        "Download as Text",
        export_content,
        "todos.txt",
        "text/plain"
    )
else:
    st.button("Download as Text", disabled=True)

# =============================================================================
# STEP 6: CLEAR ALL
# =============================================================================

st.divider()

if st.button("Clear All Todos", type="secondary"):
    save_todos([])
    st.rerun()
