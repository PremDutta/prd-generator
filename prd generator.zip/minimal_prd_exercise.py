"""
EXERCISE: Minimal PRD Generator
================================
This is a simplified version with just the core features.
Build this AFTER the todo app, BEFORE the full PRD generator.

Features:
- Input form
- Generate ONE section (overview)
- Save to file
- Show history

Run: streamlit run minimal_prd_exercise.py
"""

import streamlit as st
import json
from pathlib import Path
from datetime import datetime

# TRY TO ADD THIS YOURSELF:
# from groq import Groq

# =============================================================================
# CONFIGURATION
# =============================================================================

STORAGE_FILE = Path.home() / ".minimal_prd" / "prds.json"

# =============================================================================
# STORAGE FUNCTIONS
# Copy these from todo app - same pattern!
# =============================================================================

def init_storage():
    STORAGE_FILE.parent.mkdir(exist_ok=True)
    if not STORAGE_FILE.exists():
        STORAGE_FILE.write_text("[]")

def load_prds():
    init_storage()
    content = STORAGE_FILE.read_text()
    return json.loads(content) if content else []

def save_prd(prd):
    prds = load_prds()
    prds.insert(0, prd)
    STORAGE_FILE.write_text(json.dumps(prds, indent=2))

def delete_prd(prd_id):
    prds = load_prds()
    prds = [p for p in prds if p["id"] != prd_id]
    STORAGE_FILE.write_text(json.dumps(prds, indent=2))

# =============================================================================
# AI FUNCTION (YOU NEED TO IMPLEMENT THIS)
# =============================================================================

def generate_with_ai(prompt, api_key):
    """
    TODO: Implement this function
    
    Steps:
    1. Create Groq client: client = Groq(api_key=api_key)
    2. Call API: response = client.chat.completions.create(...)
    3. Return text: return response.choices[0].message.content
    
    For now, return a placeholder:
    """
    # PLACEHOLDER - Replace with real API call
    return f"""This is a placeholder response.

To make this work:
1. Install groq: pip install groq
2. Get API key from console.groq.com/keys
3. Implement the generate_with_ai function

Your prompt was:
{prompt[:200]}..."""

# =============================================================================
# STREAMLIT APP
# =============================================================================

st.set_page_config(page_title="Minimal PRD Generator", layout="wide")

# Session state for navigation
if "page" not in st.session_state:
    st.session_state.page = "home"

# =============================================================================
# SIDEBAR
# =============================================================================

with st.sidebar:
    st.title("📝 PRD Generator")
    st.caption("Minimal Version")
    
    st.divider()
    
    # Navigation
    if st.button("🏠 Home", use_container_width=True):
        st.session_state.page = "home"
        st.rerun()
    
    if st.button("✨ New PRD", use_container_width=True):
        st.session_state.page = "new"
        st.rerun()
    
    if st.button("📚 History", use_container_width=True):
        st.session_state.page = "history"
        st.rerun()
    
    st.divider()
    
    # API Key
    api_key = st.text_input("Groq API Key", type="password")
    if api_key:
        st.success("✅ Key set")
    else:
        st.warning("⚠️ Need key")
    
    st.divider()
    
    # Stats
    prds = load_prds()
    st.metric("PRDs", len(prds))

# =============================================================================
# PAGE: HOME
# =============================================================================

if st.session_state.page == "home":
    st.title("📝 Minimal PRD Generator")
    st.markdown("A simplified PRD generator to learn the patterns.")
    
    st.divider()
    
    st.subheader("Features")
    st.markdown("""
    - ✅ Input your feature notes
    - ✅ Generate PRD overview with AI
    - ✅ Save PRDs to file
    - ✅ View history
    - ✅ Download as Markdown
    """)
    
    st.subheader("What's Missing (add these as exercises!)")
    st.markdown("""
    - ❌ Multiple sections (add more!)
    - ❌ Section editing
    - ❌ Sharing links
    - ❌ Word/HTML export
    """)
    
    st.divider()
    
    if st.button("✨ Create New PRD", type="primary"):
        st.session_state.page = "new"
        st.rerun()

# =============================================================================
# PAGE: NEW PRD
# =============================================================================

elif st.session_state.page == "new":
    st.title("✨ Create New PRD")
    
    # Input form
    prd_name = st.text_input("PRD Name", placeholder="e.g., Data Export Feature")
    
    raw_input = st.text_area(
        "Your Notes",
        height=200,
        placeholder="""Describe your feature...

Example:
- Problem: Users can't export to Excel
- Users: Enterprise customers
- Solution: Add Excel export
- Timeline: Q1 2025"""
    )
    
    # Generate button
    if st.button("🚀 Generate PRD", type="primary"):
        if not prd_name.strip():
            st.error("Please enter a name")
        elif not raw_input.strip():
            st.error("Please enter your notes")
        elif not api_key:
            st.error("Please enter API key in sidebar")
        else:
            # Show progress
            with st.spinner("Generating..."):
                # Build prompt
                prompt = f"""You are a senior PM. Write a PRD overview.

Feature: {prd_name}

Notes:
{raw_input}

Write a professional 3-4 sentence overview covering:
- What we're building
- Why it matters
- Expected impact

Write only the content, no header."""
                
                # Call AI
                overview = generate_with_ai(prompt, api_key)
                
                # Create PRD object
                prd = {
                    "id": str(int(datetime.now().timestamp())),
                    "name": prd_name,
                    "overview": overview,
                    "raw_input": raw_input,
                    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M")
                }
                
                # Save
                save_prd(prd)
                
                # Store in session for display
                st.session_state.last_prd = prd
                st.success("PRD Generated!")
    
    # Show generated PRD
    if "last_prd" in st.session_state:
        st.divider()
        
        prd = st.session_state.last_prd
        
        st.subheader(f"📄 {prd['name']}")
        
        st.markdown("### Overview")
        st.write(prd["overview"])
        
        # Download button
        content = f"# PRD: {prd['name']}\n\n## Overview\n\n{prd['overview']}"
        st.download_button(
            "📥 Download Markdown",
            content,
            f"{prd['name']}.md"
        )

# =============================================================================
# PAGE: HISTORY
# =============================================================================

elif st.session_state.page == "history":
    st.title("📚 History")
    
    prds = load_prds()
    
    if not prds:
        st.info("No PRDs yet. Create your first one!")
    else:
        for prd in prds:
            with st.expander(f"**{prd['name']}** - {prd['created_at']}"):
                st.markdown("**Overview:**")
                st.write(prd["overview"])
                
                col1, col2 = st.columns(2)
                with col1:
                    content = f"# PRD: {prd['name']}\n\n## Overview\n\n{prd['overview']}"
                    st.download_button(
                        "📥 Download",
                        content,
                        f"{prd['name']}.md",
                        key=f"dl_{prd['id']}"
                    )
                with col2:
                    if st.button("🗑️ Delete", key=f"del_{prd['id']}"):
                        delete_prd(prd["id"])
                        st.rerun()

# =============================================================================
# FOOTER
# =============================================================================

st.divider()
st.caption("Minimal PRD Generator - Exercise Version")
